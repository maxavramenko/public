Implementation main class: StarwarsAPIMain.java
Requires maven to build. Import folder as a Java maven project
To run application build and execute StarwarsAPIMain

Usage:
At the prompt enter the search name and press <Enter>

To exit: type 'exit' at the prompt and press <Enter>